
import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, ConversationHandler

DEPOSIT, RISK_PERCENT, ENTRY, STOP, RR, LEVERAGE = range(6)
user_data = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привет! Введи депозит в $:")
    return DEPOSIT

async def get_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data['deposit'] = float(update.message.text)
    await update.message.reply_text("Риск на сделку (%)?")
    return RISK_PERCENT

async def get_risk_percent(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data['risk_percent'] = float(update.message.text)
    await update.message.reply_text("Цена входа?")
    return ENTRY

async def get_entry(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data['entry'] = float(update.message.text)
    await update.message.reply_text("Цена стопа?")
    return STOP

async def get_stop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data['stop'] = float(update.message.text)
    await update.message.reply_text("RR (например, 2 для 1:2)?")
    return RR

async def get_rr(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data['rr'] = float(update.message.text)
    await update.message.reply_text("Плечо?")
    return LEVERAGE

async def get_leverage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data['leverage'] = float(update.message.text)

    deposit = user_data['deposit']
    risk_percent = user_data['risk_percent']
    entry = user_data['entry']
    stop = user_data['stop']
    rr = user_data['rr']
    leverage = user_data['leverage']

    stop_loss = abs(entry - stop)
    risk_usd = deposit * (risk_percent / 100)
    position_size = risk_usd / stop_loss
    tp = entry + stop_loss * rr if entry > stop else entry - stop_loss * rr
    margin_required = (position_size * entry) / leverage

    msg = (
        f"📊 Расчёт:\n"
        f"— Риск: ${risk_usd:.2f}\n"
        f"— Стоп: ${stop_loss:.2f}\n"
        f"— Объём позиции: {position_size:.5f} (в базовой валюте)\n"
        f"— TP (по RR): {tp:.2f}\n"
        f"— Margin при x{leverage}: ${margin_required:.2f}"
    )
    await update.message.reply_text(msg)
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Отменено.")
    return ConversationHandler.END

if __name__ == '__main__':
    TOKEN = os.getenv("BOT_TOKEN")
    app = ApplicationBuilder().token(TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            DEPOSIT: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_deposit)],
            RISK_PERCENT: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_risk_percent)],
            ENTRY: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_entry)],
            STOP: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_stop)],
            RR: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_rr)],
            LEVERAGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_leverage)],
        },
        fallbacks=[CommandHandler('cancel', cancel)],
    )

    app.add_handler(conv_handler)
    app.run_polling()
