
# Risk Calculator Telegram Bot

## 🧮 Функционал:
- Ввод депозита, риска, стопа, RR и плеча
- Автоматический расчет объема позиции, риска, TP и маржи

## 🚀 Как задеплоить:
1. Установи переменную окружения `BOT_TOKEN`
2. Запусти `python bot.py`
3. Или задеплой на [Railway](https://railway.app)

## 📦 Файлы:
- `bot.py` — основной код
- `requirements.txt` — зависимости
- `Procfile` — для запуска на Railway
- `.env.example` — переменные окружения
